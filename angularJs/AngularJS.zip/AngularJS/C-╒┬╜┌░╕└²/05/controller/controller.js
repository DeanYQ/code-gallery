/**
 * Created by Administrator on 2017/3/2.
 */
app.controller('homeCtrl',function(){

})
.controller("menuCtrl",function(){

})
.controller("loginCtrl",function($scope,$location){
    $scope.login = function(){
        $location.path('/menu');
    }
})