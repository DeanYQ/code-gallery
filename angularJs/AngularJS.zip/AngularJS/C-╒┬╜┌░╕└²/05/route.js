/**
 * Created by Administrator on 2017/3/2.
 */
var app = angular.module('app',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){
    $routeProvider.when('/',{
        templateUrl:'template/home.html',
        controller:'homeCtrl'
    }).when('/login',{
        templateUrl:'template/login.html',
        controller:'loginCtrl'
    }).when('/menu',{
        templateUrl:'template/menu.html',
        controller:'menuCtrl'
    }).otherwise({
        redirectTo:'/'
    });
}]);
app.run(['$rootScope',function($rootScope){
    $rootScope.$on('$routeChangeStart',function(){
        console.log("路由开始改变啦！");
    });
    $rootScope.$on('$routeChangeSuccess',function(){
        console.log("路由改变成功！");
    })
}]);