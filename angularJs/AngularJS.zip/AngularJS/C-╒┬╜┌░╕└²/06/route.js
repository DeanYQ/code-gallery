/**
 * Created by Administrator on 2017/3/2.
 */
var app = angular.module('app',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){
    $routeProvider.when('/mainMenu',{ //主菜单
        templateUrl:'template/mainMenu.html',
        controller:"mainMenuCtrl"
    }).when('/userCenter',{  //会员中心
        templateUrl:'template/userCenter.html',
        controller:'userCenterCtrl'
    }).when('/myCoupon',{ //我的优惠券
        templateUrl:'template/myCoupon.html',
        controller:'couponCtrl'
    }).when('/exchange',{ //积分兑换
        templateUrl:'template/exchange.html',
        controller:'exchangeCtrl'
    }).when('/productEvaluation',{ //商品评价
        templateUrl:'template/productEvaluation.html',
        controller:'productEvaluationCtrl'
    })
    .when('/publishEvaluation',{ //发表评价
      templateUrl:'template/publishEvaluation.html',
      controller:'publishEvaluationCtrl'
    })
    .when('/topList',{ //排行榜
      templateUrl:'template/topList.html',
      controller:'topListCtrl'
    })
    .when('/promotionTimeline',{ //促销日历
      templateUrl:'template/promotionTimeline.html',
      controller:'promotionTimelineCtrl'
    })
    .when('/storeNavigation',{ //店铺导航
      templateUrl:'template/storeNavigation.html',
      controller:'storeNavigationCtrl'
    })
    .when('/scoreRecord',{ //积分记录
      templateUrl:'template/scoreRecord.html',
      controller:'scoreRecordCtrl'
    })
    .when('/notice',{ //通知
      templateUrl:'template/notice.html',
      controller:'noticeCtrl'
    })
    .otherwise({
        redirectTo:'/mainMenu'
    });
}]);
app.run(['$location','$rootScope',function($location,$rootScope){
    $rootScope.go = function(url){
        $location.path(url);
    },
    $rootScope.back = function(){
        window.history.back()
    }
}])