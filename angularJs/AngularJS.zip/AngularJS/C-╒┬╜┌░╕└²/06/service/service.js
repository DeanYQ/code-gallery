/**
 * Created by Administrator on 2017/3/2.
 */
app.service('demoService',function(){
  this.getFun1 = function(){
    return 1
  }
});
app.factory('demoFactory',function(){
  return {
    getFun1: function(){
      return 3
    }
  }
});
app.provider('demoProvider',function(){
  this.$get= function(){
    var obj = {
      getFun1: function() {
        return 4
      }
    };
    return obj
  }
});