/**
 * Created by Administrator on 2017/3/2.
 */
app.directive('iscroller',function(){
    return {
        restrict:'C',
        transclude:true,
        template:'<div id="wrapper" class="container"><div ng-transclude></div></div>',
        replace:true,
        link:function(){
            var timer = setTimeout(function(){
                var scroller = new IScroll('#wrapper', { mouseWheel: true });
                document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
            },0);
            return
        }
    }
})
app.directive('iheader', function(){
    return {
        restrict:'A',
        template:'<header><a ng-click="go(url)" class="iconfont icon-zuozuo"></a><div ng-transclude></div></header>',
        scope:{
            backUrl:'@'
        }
    }
})