/**
 * Created by Administrator on 2017/3/2.
 */
app.controller('mainMenuCtrl',function($scope,$location){
    $scope.user = {
        name:'小明',    //会员昵称
        pic:'images/zh.jpg',  // 会员头像
        level:'金卡',   // 会员等级
        points:'230',   // 积分
        remainder:'500', // 余额
        coupon:'3'   // 优惠券
    };
    $scope.menuNotes = {
        coupon:3,
        notice:2,
        points:5
    };
});
app.controller('userCenterCtrl',function($scope,$location){
    $scope.user = {
        name:'小明',
        levelValue:'7500',
        levelPercent:'85%',
        pic:'images/zh.jpg',
        level:'金卡',
        mobile:'139-0000-0000',
        birthday:'1980-01-01',
        sex:"男"
    }
    $scope.userRules = [
        "1、会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍",
        "2、会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍介绍会员介绍会员介绍",
        "3、会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍介绍会员介绍会员介绍介绍会员介绍会员介绍",
        "4、会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍会员介绍介绍会员介绍会员介绍介绍会员介绍会员介绍介绍会员介绍会员介绍",
    ]
});
app.controller('couponCtrl',function($scope){
    $scope.coupons = [
        {pic:"images/card2.png",percent:'10%',dateLimit:'三',status:1},
        {pic:"images/card3.png",percent:'10%',dateLimit:'三',status:2},
        {pic:"images/card4.png",percent:'15%',dateLimit:'一',status:3}
    ]
    $scope.checkDetail = function(){
        $scope.showDetail = true
    },
    $scope.closePop = function() {
        $scope.showDetail = false
    }
})
app.controller('exchangeCtrl',function($scope){
    $scope.exchanges = [
        {pic:"images/card2.png",percent:'10%',dateLimit:'三',status:1},
        {pic:"images/card3.png",percent:'10%',dateLimit:'三',status:2},
        {pic:"images/card4.png",percent:'15%',dateLimit:'一',status:3}
    ]
    $scope.checkDetail = function(){
        $scope.showDetail = true
    },
    $scope.closePop = function() {
      $scope.showDetail = false
    }
    $scope.levelUp = function(){
        $scope.layerUp = true
    }
});
app.controller('productEvaluationCtrl',function($scope){
    $scope.tab1 = true
});
app.controller('publishEvaluationCtrl',function($scope){
});
app.controller('topListCtrl',function($scope){
});
app.controller('promotionTimelineCtrl',function($scope){
});
app.controller('storeNavigationCtrl',function($scope){
});
app.controller('scoreRecordCtrl',function($scope){
});
app.controller('noticeCtrl',function($scope,demoService,demoFactory,demoProvider){
    console.log(demoService.getFun1())
    console.log(demoFactory.getFun1())
    console.log(demoProvider.getFun1())
});