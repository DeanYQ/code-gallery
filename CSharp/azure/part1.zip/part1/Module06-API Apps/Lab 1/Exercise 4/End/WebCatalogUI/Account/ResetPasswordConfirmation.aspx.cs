﻿using System.Web.UI;

namespace WebCatalogUI.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}