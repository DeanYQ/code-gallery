﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using PictureAPI.Models;
using Swashbuckle.Swagger.Annotations;


namespace PictureAPI.Controllers
{
    public class ProductsController : ApiController
    {
        private EFContext db = new EFContext();

        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return db.Products;
        }

        /// <summary>
        /// Returns the specified contact.
        /// </summary>
        /// <param name="id">The ID of the contact.</param>
        /// <returns>A contact record with an HTTP 200, or null HTTP 404.</returns>
        /// <response code="200">OK</response>
        /// <response code="404">Not Found</response>
        [HttpGet]

        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.NotFound)]

        [ResponseType(typeof(Product))]
        public HttpResponseMessage Get(string id)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }
            else
            {
                return Request.CreateResponse<Product>(HttpStatusCode.OK, product);
            }

        }

        [HttpGet]
        [Route("api/products/{skipTo}/{count}")]
        public IEnumerable<Product> Get([FromUri]int skipTo, [FromUri]int count)
        {
            return db.Products.OrderBy(p => p.Price).Skip(skipTo).Take(count);
        }
    }

}
