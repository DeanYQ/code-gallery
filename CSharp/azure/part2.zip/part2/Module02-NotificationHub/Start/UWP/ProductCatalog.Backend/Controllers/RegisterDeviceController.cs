﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.IO;

namespace WAAD.POC.ProductCatalog.Backend.Controllers
{
    public class RegisterDeviceController : ApiController
    {

        // POST api/RegisterDevice
        public void Post([FromBody] string value)
        {


        }
        
    }
}
