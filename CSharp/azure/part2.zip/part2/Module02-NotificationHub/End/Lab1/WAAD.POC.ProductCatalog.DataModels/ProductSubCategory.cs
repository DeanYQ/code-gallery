﻿namespace WAAD.POC.ProductCatalog.DataModels
{
    public class ProductSubCategory
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string ImagePath { get; set; }

        public int ProductCount { get; set; }
    }
}
