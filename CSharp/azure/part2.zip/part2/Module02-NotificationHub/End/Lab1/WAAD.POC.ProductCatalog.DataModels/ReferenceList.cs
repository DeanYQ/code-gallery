﻿namespace WAAD.POC.ProductCatalog.DataModels
{
    class ReferenceList
    {
        public string Id { get; set; }
        public string Value { get; set; }
    }
}
