﻿namespace WAAD.POC.ProductCatalog.DataModels
{
    public class SectionGroup
    {
        public string Title { get; set; }

            public object Items { get; set; }
 
    }
}
