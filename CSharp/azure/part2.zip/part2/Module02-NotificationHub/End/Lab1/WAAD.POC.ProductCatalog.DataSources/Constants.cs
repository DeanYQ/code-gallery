﻿namespace WAAD.POC.ProductCatalog.DataSources
{
    static class Constants
    {
        public static string CategoryFile = "Category.xml";
        public static string ProductFile = "Product.xml";
        public static string DefaultFavoritesFile = "Favorites.xml";
    }
}
