﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using System.IO;
using System.Net.Http.Headers;

namespace XMLPublisher.Controllers
{
    public class XMLPublisherController : ApiController
    {
        [HttpGet]
        [ActionName("XMLProduct")]
        public HttpResponseMessage GetXMLProduct()
        {
            XMLFileGeneration.CreateProductXMLFile();
            HttpResponseMessage result = null;
            using (MemoryStream ms = new MemoryStream())
            using (FileStream file = new FileStream(System.IO.Path.GetTempPath() + "Product.xml", FileMode.Open, FileAccess.Read))
            {
                byte[] bytes = new byte[file.Length];
                file.Read(bytes, 0, (int)file.Length);
                ms.Write(bytes, 0, (int)file.Length);
                result = Request.CreateResponse(HttpStatusCode.OK);
                result.Content = new ByteArrayContent(ms.ToArray());
                result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                result.Content.Headers.ContentDisposition.FileName = "Product.xml";
                result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/xml");
            }
            return result;
        }

        [HttpGet]
        [ActionName("XMLCategory")]
        public HttpResponseMessage GetXMLCategory()
        {
            XMLFileGeneration.CreateCategoryXMLFile();
            HttpResponseMessage result = null;
            using (MemoryStream ms = new MemoryStream())
            using (FileStream file = new FileStream(System.IO.Path.GetTempPath() + "Category.xml", FileMode.Open, FileAccess.Read))
            {
                byte[] bytes = new byte[file.Length];
                file.Read(bytes, 0, (int)file.Length);
                ms.Write(bytes, 0, (int)file.Length);
                result = Request.CreateResponse(HttpStatusCode.OK);
                result.Content = new ByteArrayContent(ms.ToArray());
                result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                result.Content.Headers.ContentDisposition.FileName = "Category.xml";
                result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/xml");
            }
            return result;
        }
    }
}

