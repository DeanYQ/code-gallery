﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Xml.Linq;
using System.Xml;
using System.IO;
using XMLDBImport;

namespace XMLPublisher
{
    public class XMLFileGeneration
    {
        public static void CreateProductXMLFile()
        {
            XElement arrayOfProduct;
            XmlWriterSettings xws = new XmlWriterSettings();
            xws.OmitXmlDeclaration = true;
            xws.Indent = true;
            xws.NamespaceHandling = NamespaceHandling.OmitDuplicates;
            xws.CloseOutput = true;

            XNamespace ns = "http://schemas.datacontract.org/2004/07/WAAD.POC.ProductCatalog.DataModels";

            //Generate Product.xml
            using (var ctx = new EFContext())
            {
                List<Product> lstProduct = ctx.Products.Include("ProductSpecifications").ToList();
                arrayOfProduct = new XElement(ns + "ArrayOfProduct",
                                              from p in lstProduct
                                              select new XElement(ns + "Product",
                                                         new XElement(ns + "Brand", p.Brand),
                                                         new XElement(ns + "Category", p.Category),
                                                         new XElement(ns + "Description", p.Description),
                                                         new XElement(ns + "GroupNumber", p.GroupNumber),
                                                         new XElement(ns + "Id", p.Id),
                                                         new XElement(ns + "ImagePath", p.ImagePath),
                                                         new XElement(ns + "Name", p.Name),
                                                         new XElement(ns + "Price", p.Price),
                                                         new XElement(ns + "ProductColor", p.ProductColor),
                                                         new XElement(ns + "ProductSpecifications",
                                                             from ps in p.ProductSpecifications
                                                             select new XElement(ns + "ProductSpecification",
                                                                    new XElement(ns + "AllowComparision", ps.AllowComparision),
                                                                    new XElement(ns + "AllowFiltering", ps.AllowFiltering),
                                                                    new XElement(ns + "Name", ps.Name),
                                                                    new XElement(ns + "Value", ps.Value)
                                                 )
                                              ),
                                          new XElement(ns + "SubCategory", p.SubCategory)
                                          )
                                     );
            }
            using (XmlWriter xw = XmlWriter.Create(File.Create(System.IO.Path.GetTempPath() + "Product.xml"), xws))
            {
                arrayOfProduct.Save(xw);
            }
        }

        public static void CreateCategoryXMLFile()
        {
            XElement arrayOfProductCategory;
            XmlWriterSettings xws = new XmlWriterSettings();
            xws.OmitXmlDeclaration = true;
            xws.Indent = true;
            xws.NamespaceHandling = NamespaceHandling.OmitDuplicates;
            xws.CloseOutput = true;
            XNamespace ns = "http://schemas.datacontract.org/2004/07/WAAD.POC.ProductCatalog.DataModels";

            //Generate Category.xml
            using (var ctx = new EFContext())
            {
                List<ProductCategory> lstProductCategory = ctx.ProductCategories.Include("SubCategoryItems").ToList();
                arrayOfProductCategory = new XElement(ns + "ArrayOfProductCategory",
                                              from pc in lstProductCategory
                                              select new XElement(ns + "ProductCategory",
                                                         new XElement(ns + "Id", pc.Id),
                                                         new XElement(ns + "IamgePath", pc.ImagePath),
                                                         new XElement(ns + "Name", pc.Name),
                                                         new XElement(ns + "SubCategoryItems",
                                                             from psc in pc.SubCategoryItems
                                                             select new XElement(ns + "ProductSubCategory",
                                                                    new XElement(ns + "Id", psc.Id),
                                                                    new XElement(ns + "ImagePath", psc.ImagePath),
                                                                    new XElement(ns + "Name", psc.Name),
                                                                    new XElement(ns + "ProductCount", psc.ProductCount)
                                                 )
                                              )
                                          )
                                     );
            }

            using (FileStream fs = File.Create(System.IO.Path.GetTempPath() + "Category.xml"))
            using (XmlWriter xw = XmlWriter.Create(fs, xws))
            {
                arrayOfProductCategory.Save(xw);
            }
        }
    }

}