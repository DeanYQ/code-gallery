﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;

namespace ImageDownloader
{
    class Program
    {
        static async Task<string> RunAsyncGetSASKey()
        {
            using (var client = new HttpClient())
            {
                string serviceRelativeAddress = string.Format(System.Configuration.ConfigurationManager.AppSettings["SASManagement"], "productimages");
                client.BaseAddress = new Uri(System.Configuration.ConfigurationManager.AppSettings["ServiceBaseAddress"]);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // HTTP GET
                HttpResponseMessage response = await client.GetAsync(serviceRelativeAddress);
                if (response.IsSuccessStatusCode)
                {
                    string SASKey = await response.Content.ReadAsStringAsync();
                    return SASKey;
                }
                else
                    return null;
            }
        }

        static void Main(string[] args)
        {
            //Get the SAS key
            string SASKey = Task.Run(() => RunAsyncGetSASKey()).Result;

            //remove the " character
            char[] charsToTrim = { '\"' };
            SASKey = SASKey.Trim(charsToTrim);

            //List Image
            ImageLoader.ImageLoaderUtilities imageCollector = new ImageLoader.ImageLoaderUtilities();
            List<string> URIList = imageCollector.ListImage(SASKey, "productimages");

            URIList = imageCollector.ListImageAfterADate(SASKey, "productimages", DateTime.UtcNow.AddDays(-3));

            //Download All Images
            imageCollector.DownloadAll(SASKey, "productimages", @"F:\DownloadImages");

            //Download Images After a Date
            imageCollector.DownloadAfterADate(SASKey, "productimages", @"F:\DownloadImages", DateTime.UtcNow.AddDays(-1));
        }
    }
}
