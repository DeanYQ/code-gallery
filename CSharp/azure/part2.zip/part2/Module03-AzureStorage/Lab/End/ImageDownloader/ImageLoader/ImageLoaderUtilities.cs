﻿using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageLoader
{

    public class ImageLoaderUtilities
    {
        public List<string> ListImage(string sas, string containerName)
        {
            CloudBlobContainer container = new CloudBlobContainer(new Uri(sas));

            List<string> URIList = new List<string>();

            // Loop over items within the container and output the length and URI.
            foreach (IListBlobItem item in container.ListBlobs(null, false))
            {
                CloudBlockBlob blob = (CloudBlockBlob)item;

                //Console.WriteLine("Block blob of length {0}: {1}", blob.Properties.Length, blob.Uri);
                URIList.Add(blob.Uri.ToString());
            }

            return URIList;
        }

        public List<string> ListImageAfterADate(string sas, string containerName, DateTime dateTime)
        {
            CloudBlobContainer container = new CloudBlobContainer(new Uri(sas));

            List<string> URIList = new List<string>();

            var blobs = container.ListBlobs().OfType<CloudBlob>()
                                .Where(b => b.Properties.LastModified >= dateTime);

            // Loop over items within the container and output the length and URI.
            foreach (IListBlobItem item in blobs)
            {
                CloudBlockBlob blob = (CloudBlockBlob)item;

                //Console.WriteLine("Block blob of length {0}: {1}", blob.Properties.Length, blob.Uri);
                URIList.Add(blob.Uri.ToString());
            }

            return URIList;
        }

        public void DownloadAfterADate(string sas, string containerName, string localPathToDownload, DateTime dateTime)
        {
            // Create the blob client.
            //CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = new CloudBlobContainer(new Uri(sas));

            var blobs = container.ListBlobs().OfType<CloudBlob>()
                          .Where(b => b.Properties.LastModified >= dateTime);


            foreach (IListBlobItem item in blobs)
            {
                CloudBlockBlob blockBlob = (CloudBlockBlob)item;

                using (var fileStream = System.IO.File.OpenWrite(localPathToDownload + @"\" + blockBlob.Name))
                {
                    blockBlob.DownloadToStream(fileStream);
                }
            }

        }

        public void DownloadAll(string sas, string containerName, string localPathToDownload)
        {
            // Create the blob client.
            //            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to a previously created container.
            //          CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            CloudBlobContainer container = new CloudBlobContainer(new Uri(sas));


            foreach (IListBlobItem item in container.ListBlobs(null, false))
            {
                CloudBlockBlob blockBlob = (CloudBlockBlob)item;
                //blockBlob.

                using (var fileStream = System.IO.File.OpenWrite(localPathToDownload + @"\" + blockBlob.Name))
                {
                    blockBlob.DownloadToStream(fileStream);
                }
            }

        }

    }
}
