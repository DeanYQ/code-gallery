﻿using System.Web.Http;

namespace SASManagementService.Controllers
{
    public class SASManagementController : ApiController
    {
        [HttpGet]
        [ActionName("SASKey")]
        public string GetSASKey(string containerName)
        {
            return SASGenerator.ProvideSASKey(containerName);
        }
    }
}
