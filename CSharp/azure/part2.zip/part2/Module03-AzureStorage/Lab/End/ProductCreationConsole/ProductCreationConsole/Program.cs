﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XMLDBImport;
using ProductCreationLib;

namespace ProductCreationConsole
{
    class Program
    {
    static void Main(string[] args)
    {
        //Variable declaration
        Product p = new Product();
        ProductSpecification ps = new ProductSpecification();
        p.ProductSpecifications = new List<ProductSpecification>();

        //Initialize the Production Specification object
        ps.Id = 200;
        ps.AllowComparision = true;
        ps.AllowFiltering = true;
        ps.Name = "Capacity";
        ps.Value = "200GB";

        //Initialize the Product object
        p.Brand = "Microsoft";
        p.Category = "2";
        p.Description = "Powerful game console";
        p.GroupNumber = "2222222";
        p.Name = "XBOX One";
        p.Price = 200;
        p.ProductColor = "Black";
        p.Id = "3333333";
        p.ImagePath = @"/Data/ProductImages/XBoxOne.png";
        p.ProductSpecifications.Add(ps);

        string fullPathToImage = @"F:\FastStartWin10Azure\Module4\Start\Assets\XBoxOne.png";
        string containerName = "productimages";

        //Call for Product creation on the DB
        ProductCreationUtilities.AddProductInDB(p);

        //Call for product image upload
        ProductCreationUtilities.UploadImage(fullPathToImage, containerName);
    }
    }
}
