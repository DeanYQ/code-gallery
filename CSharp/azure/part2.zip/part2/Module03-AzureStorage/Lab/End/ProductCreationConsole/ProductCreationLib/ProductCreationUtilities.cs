﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using XMLDBImport;
using Microsoft.Azure;

namespace ProductCreationLib
{
    public class ProductCreationUtilities
    {
        public static void AddProductInDB(Product productToAdd)
        {
            MyDbInitializer dbi = new MyDbInitializer();
            dbi.InitializeDatabase(new EFContext());

            using (var ctx = new EFContext())
            {
                ctx.Products.Add(productToAdd);
                ctx.SaveChanges();
            }
        }

        public static void UploadImage (string fullPathToImage, string containerName)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            //Create the blob client object.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            char[] mySeparators= { '\\' };
            // Retrieve reference to a blob named "myblob".
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(fullPathToImage.Substring (fullPathToImage.LastIndexOfAny(mySeparators)+1));

            // Create or overwrite the "myblob" blob with contents from a local file.
            using (var fileStream = System.IO.File.OpenRead(fullPathToImage))
            {
                blockBlob.UploadFromStream(fileStream);
            }
        }

    }
}
