﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Blob;

namespace ImageLoader
{

    public static class ImageLoaderUtilities
    {
        async public static Task<List<string>> ListAllAsync(string sas, string containerName)
        {
            return await OperateAfterADateAsync(sas, containerName, DateTime.MaxValue);
        }

        async public static Task<List<string>> ListAfterADateAsync(string sas, string containerName,
                                                    DateTime dateTime)
        {
            return await OperateAfterADateAsync(sas, containerName, dateTime);
        }

        async public static Task<List<string>> DownloadAllAsync(string sas, string containerName,
                                                    string localPathToDownload)
        {
            var downloadedList = await
                OperateAfterADateAsync(sas, containerName, DateTime.MaxValue, localPathToDownload);

            return downloadedList;
        }

        async public static Task<List<string>> DownloadAfterADateAsync(string sas, string containerName,
                                                    string localPathToDownload, DateTime dateTime)
        {
            var downloadedList = await
                OperateAfterADateAsync(sas, containerName, dateTime, localPathToDownload);

            return downloadedList;
        }

        async private static Task<List<string>> OperateAfterADateAsync(string sas, string containerName,
                                                    DateTime dateTime, string localPathToDownload = null)
        {
            CloudBlobContainer container = new CloudBlobContainer(new Uri(sas));
            List<string> URIList = new List<string>();

            BlobContinuationToken continuationToken = null;
            do
            {
                BlobResultSegment blobSegments = await container.ListBlobsSegmentedAsync(null, continuationToken);
                IEnumerable<CloudBlob> blobs;

                // don't filter to return all blobs
                if (dateTime == DateTime.MaxValue)
                {
                    blobs = blobSegments.Results.OfType<CloudBlob>();
                }
                else   // filter blobs updated after the given date
                {
                    blobs = blobSegments.Results.OfType<CloudBlob>()
                                    .Where(b => b.Properties.LastModified >= dateTime);
                }

                // store the Uri of each blob
                foreach (IListBlobItem item in blobs)
                {
                    CloudBlockBlob blockBlob = (CloudBlockBlob)item;
                    URIList.Add(blockBlob.Uri.ToString());

                    // and download if needed
                    if (localPathToDownload != null)
                    {
                        using (var fileStream = System.IO.File.OpenWrite(
                                    localPathToDownload + @"\" + blockBlob.Name))
                        {
                            await blockBlob.DownloadToStreamAsync(fileStream.AsOutputStream());
                        }
                    }
                }

                // the continuation token will be null when there is no more blob to get
                continuationToken = blobSegments.ContinuationToken;
            } while (continuationToken != null);

            return URIList;
        }
    }
}
