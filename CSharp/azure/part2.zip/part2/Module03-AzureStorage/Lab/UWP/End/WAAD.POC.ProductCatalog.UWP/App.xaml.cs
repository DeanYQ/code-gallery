﻿using System;
using System.Diagnostics;
using System.Linq;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Globalization;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using WAAD.POC.ProductCatalog.DataModels;
using WAAD.POC.ProductCatalog.DataSources;
using WAAD.POC.ProductCatalog.UWP.Common;
using WAAD.POC.ProductCatalog.UWP.View;
using System.Threading.Tasks;
using Windows.Storage;
using ImageLoader;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;


// The Blank Application template is documented at http://go.microsoft.com/fwlink/?LinkId=402347&clcid=0x409

namespace WAAD.POC.ProductCatalog.UWP
{
    /// <summary>
    /// Provides application-specific behavior to supplement the default Application class.
    /// </summary>
    sealed partial class App 
    {
        /// <summary>
        /// Initializes the singleton application object.  This is the first line of authored code
        /// executed, and as such is the logical equivalent of main() or WinMain().
        /// </summary>
        public App()
        {
            InitializeComponent();
            Suspending += OnSuspending;
        }

        /// <summary>
        /// Invoked when the application is launched normally by the end user.  Other entry points
        /// will be used such as when the application is launched to open a specific file.
        /// </summary>
        /// <param name="e">Details about the launch request and process.</param>
        protected override async void OnLaunched(LaunchActivatedEventArgs e)
        {

#if DEBUG
            if (Debugger.IsAttached)
            {
                DebugSettings.EnableFrameRateCounter = false;
            }
#endif
            // Lab3 - create the cache the first time the application is launched
            await SetupLocalCacheAsync();

            //Initialize the Data Manager + Default Favorites collection
            DataManager.Initialize(new LocalStoreDataService<ProductCategory>(),
                                new LocalStoreDataService<Product>(), new LocalStoreDataService<string>());
            FavoritesHelper.DefaultFavorites = (await DataManager.DefaultFavoritesDataSource.GetAllAsync()).ToList();

            // Lab 3 - reroute the image path to point to the local cache files...
            // ... for categories and subcategories
            foreach (var category in await DataManager.CategoryDataSource.GetAllAsync())
            {
                category.ImagePath = 
                    string.Concat(ApplicationData.Current.LocalFolder.Path, category.ImagePath);

                foreach (var subcategory in category.SubCategoryItems)
                {
                    subcategory.ImagePath =
                        string.Concat(ApplicationData.Current.LocalFolder.Path, subcategory.ImagePath);
                }
            }

            // ... and for products
            foreach (var product in await DataManager.ProductDataSource.GetAllAsync())
            {
                product.ImagePath = 
                    string.Concat(ApplicationData.Current.LocalFolder.Path, product.ImagePath);
            }

            // Lab 3 - get the new and updated images
            await RefreshImageCacheAsync();

            //attempt to get current Toot Frame
            Frame rootFrame = Window.Current.Content as Frame;

            // Do not repeat app initialization when the Window already has content,
            // just ensure that the window is active
            if (rootFrame == null)
            {
                // Create a Frame to act as the navigation context and navigate to the first page
                rootFrame = new Frame();
                // Set the default language
                rootFrame.Language = ApplicationLanguages.Languages[0];

                rootFrame.NavigationFailed += OnNavigationFailed;

                if (e.PreviousExecutionState == ApplicationExecutionState.Terminated)
                {
                    //TODO: Load state from previously suspended application
                }
            }

            // Place the frame in the current Window
            Window.Current.Content = new AppShell(rootFrame);
            string param = e.Arguments ?? "";

            if (rootFrame.Content == null)
            {
                // When the navigation stack isn't restored navigate to the first page,
                // configuring the new page by passing required information as a navigation
                // parameter

                // If a launch parameter is provided (ie. from Secondary Tile), navigate to the product Page 
                // - otherwise go to the Home page.
                rootFrame.Navigate(param != "" ? typeof (ViewProductPage) : typeof (HomePage), e.Arguments);
            }
            else
            {
                if (param != "")
                    AppShell.Current.NavCommand.Execute(new NavType() { Type = typeof(ViewProductPage), Parameter = param });
            }
            // Ensure the current window is active
            Window.Current.Activate();
        }


        // TODO: change the BASE_ADDRESS with your own Azure web site address
        const string BASE_ADDRESS = "http://<replace with storage account>.azurewebsites.net";
        const string SERVICE_RELATIVE_ADDRESS = "/api/SASManagement/SASKey?containerName={0}";
        async private Task<string> GetSASKeyAsync(string containerName)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BASE_ADDRESS);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // send the HTTP GET request
                string serviceRelativeAddress = string.Format(SERVICE_RELATIVE_ADDRESS, containerName);
                HttpResponseMessage response = await client.GetAsync(serviceRelativeAddress);
                if (response.IsSuccessStatusCode)
                {
                    string SASKey = await response.Content.ReadAsStringAsync();
                    SASKey = SASKey.Trim('\"');  // remove quotes
                    return SASKey;
                }
                else
                    return null;
            }
        }
        async private Task RefreshImageCacheAsync()
        {
            DateTime now = DateTime.Now;

            string sasKey;
            string localCache;
            string container;

            // get the new/updated category images
            container = "productcategoryimages";
            sasKey = await GetSASKeyAsync(container);
            localCache = await GetLocalCachePathAsync("ProductCategoryImages");
            await ImageLoaderUtilities.DownloadAfterADateAsync(sasKey, container, localCache, now);

            // get the new/updated product images
            container = "productimages";
            sasKey = await GetSASKeyAsync(container);
            localCache = await GetLocalCachePathAsync("ProductImages");
            await ImageLoaderUtilities.DownloadAfterADateAsync(sasKey, container, localCache, now);
        }

        async private Task<string> GetLocalCachePathAsync(string subFolder)
        {
            StorageFolder dataFolder =
                await ApplicationData.Current.LocalFolder.CreateFolderAsync(
                        "Data",
                        CreationCollisionOption.OpenIfExists
                        );
            return Path.Combine(dataFolder.Path, subFolder);
        }

        async private Task SetupLocalCacheAsync()
        {
            string key = "SETTINGS_KEY_EXECUTED_SINCE_INSTALLATION";

            // create the cache only if it was not created before
            if (ApplicationData.Current.LocalSettings.Values.ContainsKey(key))
                return;

            // create the Data folder in the application data 
            StorageFolder dataFolder = 
                await ApplicationData.Current.LocalFolder.CreateFolderAsync(
                    "Data", 
                    CreationCollisionOption.OpenIfExists
                    );

            // create and fill up the category images subfolder
            await CreateAndFillUpDataSubfolder(dataFolder, "ProductCategoryImages");

            // create and fill up the product images subfolder
            await CreateAndFillUpDataSubfolder(dataFolder, "ProductImages");

            // remember that the cache has been set up
            ApplicationData.Current.LocalSettings.Values[key] = "true";
        }

        async private Task CreateAndFillUpDataSubfolder(StorageFolder dataFolder, string subFolderName)
        {
            // reach Data\subfolder under the readonly installation package folder 
            StorageFolder packageSubFolder = Package.Current.InstalledLocation;
            packageSubFolder = await packageSubFolder.GetFolderAsync("Data");
            packageSubFolder = await packageSubFolder.GetFolderAsync(subFolderName);

            // create the corresponding subfolder in the cache
            StorageFolder cacheSubfolder =
                await dataFolder.CreateFolderAsync(
                    subFolderName,
                    CreationCollisionOption.OpenIfExists
                    );

            // copy each file in the package to the local cache folder
            foreach (var packageFile in await packageSubFolder.GetFilesAsync())
            {
                // get the corresponding file in the cache
                StorageFile dataFile = 
                    await cacheSubfolder.CreateFileAsync(
                        packageFile.Name, 
                        CreationCollisionOption.ReplaceExisting
                        );
                
                // copy the package file to the cache
                await packageFile.CopyAndReplaceAsync(dataFile);
            }
        }

        /// <summary>
        /// Invoked when Navigation to a certain page fails
        /// </summary>
        /// <param name="sender">The Frame which failed navigation</param>
        /// <param name="e">Details about the navigation failure</param>
        void OnNavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            throw new Exception("Failed to load Page " + e.SourcePageType.FullName);
        }

        /// <summary>
        /// Invoked when application execution is being suspended.  Application state is saved
        /// without knowing whether the application will be terminated or resumed with the contents
        /// of memory still intact.
        /// </summary>
        /// <param name="sender">The source of the suspend request.</param>
        /// <param name="e">Details about the suspend request.</param>
        private void OnSuspending(object sender, SuspendingEventArgs e)
        {
            var deferral = e.SuspendingOperation.GetDeferral();
            //TODO: Save application state and stop any background activity
            deferral.Complete();
        }
    }
}
